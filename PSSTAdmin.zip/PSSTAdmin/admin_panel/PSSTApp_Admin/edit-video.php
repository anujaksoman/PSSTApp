<?php include('session.php'); ?>
<?php include('public/menubar.php'); ?>

<link href="assets/css/bootstrap-select.css" rel="stylesheet">
<style>
div.ex1 {
    margin-bottom: 8px;
}
</style>
<script src="assets/js/ckeditor/ckeditor.js"></script>

<script src="assets/js/jquery-1.9.1.min.js"></script>

<?php include('public/edit-video-form.php'); ?>
<?php include('public/footer.php'); ?>