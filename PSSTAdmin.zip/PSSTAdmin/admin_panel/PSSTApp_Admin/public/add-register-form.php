<?php 
    include('public/fcm.php');
    require_once("public/thumbnail_images.class.php");

    if(isset($_POST['submit'])) {

        $video_id = 'cda11up';

                $data = array(

                    'category_id'       => $_POST['cat_id'],            
                    'register_name'     => $_POST['name'],
                    'register_address'  => $_POST['address'],                              
                    'register_contact'  => $_POST['contact'],
                    'register_email'    => $_POST['email'],                                    
                    'register_pname'    => $_POST['pname'],
                    'register_pcontact' => $_POST['pcontact'],
                    'college_id'        => $_POST['college_id'],
                    'course_id'         => $_POST['course_id'],
                    'tech_id'           => $_POST['tech_id'],
                    'register_dob'      => $_POST['dob'],
                    
                    );      

                      $qry = Insert('tbl_register', $data);                                  
                      
                      $_SESSION['msg'] = "";
                      header( "Location:add-register.php");
                      exit;

    }

    $wall_qry = "SELECT * FROM tbl_category";
    $wall_result = mysqli_query($connect, $wall_qry);

    $wall_qry1 = "SELECT * FROM tbl_college";
    $wall_result1 = mysqli_query($connect, $wall_qry1);

    $wall_qry2 = "SELECT * FROM tbl_course";
    $wall_result2 = mysqli_query($connect, $wall_qry2);

    $wall_qry3 = "SELECT * FROM tbl_tech";
    $wall_result3 = mysqli_query($connect, $wall_qry3);

?>

   <section class="content">
   
        <ol class="breadcrumb">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage-register.php">Manage Registration</a></li>
            <li class="active">Add Registration</a></li>
        </ol>

       <div class="container-fluid">

            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                	<form id="form_validation" method="post" enctype="multipart/form-data">
                    <div class="card">
                        <div class="header">
                            <h2>ADD Registration</h2>
                                <?php if(isset($_SESSION['msg'])) { ?>
                                    <br><div class='alert alert-info'>New Registration Added Successfully...</div>
                                    <?php unset($_SESSION['msg']); } ?>
                        </div>
                        <div class="body">

                        	<div class="row clearfix">
                                
                                <div class="col-sm-5">

                                    <div class="form-group">
                                        <div class="font-12">Name *</div>
                                        <div class="form-line">
                                            <input type="text" class="form-control" name="name" id="name" placeholder="Name" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Address *</div>
                                        <div class="form-line">
                                            <textarea name="address" id="address" class="form-control" placeholder="Address" required ></textarea>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Contact *</div>
                                        <div class="form-line">
                                            <input type="text" name="contact" id="contact" class="form-control" placeholder="Contact" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Email *</div>
                                        <div class="form-line">
                                            <input type="email" name="email" id="email" class="form-control" placeholder="Email" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">DOB *</div>
                                        <div class="form-line">
                                            <input type="date" name="dob" id="dob" class="form-control" placeholder="Date of Birth" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Parent Name *</div>
                                        <div class="form-line">
                                            <input type="text" name="pname" id="pname" class="form-control" placeholder="Parent Name" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Parent Contact *</div>
                                        <div class="form-line">
                                            <input type="text" name="pcontact" id="pcontact" class="form-control" placeholder="Parent Contact" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">College *</div>
                                        <select class="form-control show-tick" name="college_id" id="college_id">
                                            <?php while ($data1 = mysqli_fetch_array ($wall_result1)) { ?>
                                            <option value="<?php echo $data1['college_id'];?>"><?php echo $data1['college_name'];?></option>
                                                <?php } ?>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="font-12">Course *</div>
                                        <select class="form-control show-tick" name="course_id" id="course_id">
                                            <?php while ($data2 = mysqli_fetch_array($wall_result2)) { ?>
                                            <option value="<?php echo $data2['course_id'];?>"><?php echo $data2['course_name'];?></option>
                                                <?php } ?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Category *</div>
                                        <select class="form-control show-tick" name="cat_id" id="cat_id">
                                            <?php while ($data = mysqli_fetch_array ($wall_result)) { ?>
                                            <option value="<?php echo $data['cid'];?>"><?php echo $data['category_name'];?></option>
                                                <?php } ?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Technology *</div>
                                        <select class="form-control show-tick" name="tech_id" id="tech_id">
                                            <?php while ($data3 = mysqli_fetch_array ($wall_result3)) { ?>
                                            <option value="<?php echo $data3['tech_id'];?>"><?php echo $data3['tech_name'];?></option>
                                                <?php } ?>
                                        </select>
                                    </div>


                                    <button type="submit" name="submit" class="btn bg-blue waves-effect pull-right">PUBLISH</button>
                                    
                                </div>

                            </div>
                        </div>
                    </div>
                    </form>

                </div>
            </div>
            
        </div>

    </section>