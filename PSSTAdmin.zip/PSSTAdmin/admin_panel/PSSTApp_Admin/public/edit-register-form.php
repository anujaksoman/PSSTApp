<?php 
    

	if(isset($_GET['id'])) {
 		$qry 	= "SELECT * FROM tbl_register WHERE register_id ='".$_GET['id']."'";
		$result = mysqli_query($connect, $qry);
		$row 	= mysqli_fetch_assoc($result);
 	}

	if(isset($_POST['submit'])) {


        $up="update tbl_register set category_id='".$_POST['cat_id']."',register_name='".$_POST['name']."',register_address='".$_POST['address']."',register_contact='".$_POST['contact']."',register_email='".$_POST['email']."',register_pname='".$_POST['pname']."',register_pcontact='".$_POST['pcontact']."',college_id='".$_POST['college_id']."',course_id='".$_POST['course_id']."',tech_id='".$_POST['tech_id']."',register_dob='".$_POST['register_dob']."' WHERE register_id = '".$_POST['id']."'";
        mysqli_query($connect,  $up);
        $_SESSION['msg'] = "";
		header( "Location:edit-register.php?id=".$_POST['id']);
		exit;
        // echo $_POST['cat_id'];
		//$video_id = 'cda11up';
	
			// $data = array(											 
            //     'category_id'       => $_POST['cat_id'],            
            //     'register_name'     => $_POST['name'],
            //     'register_address'  => $_POST['address'],                              
            //     'register_contact'  => $_POST['contact'],
            //     'register_email'    => $_POST['email'],                                    
            //     'register_pname'    => $_POST['pname'],
            //     'register_pcontact' => $_POST['pcontact'],
            //     'college_id'        => $_POST['college_id'],
            //     'course_id'         => $_POST['course_id'],
            //     'tech_id'           => $_POST['tech_id'],
            //     'register_dob'      => $_POST['dob'],

            // );
            // $data['category_id'] = $_POST['cat_id'];
            // $data['register_name'] = $_POST['name'];
            // $data['register_address'] = $_POST['address'];
            // $data['register_contact'] = $_POST['contact'];
            // $data['register_email'] = $_POST['email'];
            // $data['register_pname'] = $_POST['pname'];
            // $data['register_pcontact'] = $_POST['pcontact'];
            // $data['college_id'] = $_POST['college_id'];
            // $data['course_id'] = $_POST['course_id'];
            // $data['tech_id'] = $_POST['tech_id'];
            // $data['register_dob'] = $_POST['dob'];


			// $hasil = Update('tbl_register', $data, "WHERE register_id = '".$_POST['id']."'");

			// if ($hasil > 0) {
			// $_SESSION['msg'] = "";
			// header( "Location:edit-register.php?id=".$_POST['id']);
			// exit;
	}


 	$sql_query = "SELECT * FROM tbl_category";
    $ringtone_qry_cat = mysqli_query($connect, $sql_query);
    
    $wall_qry1 = "SELECT * FROM tbl_college";
    $ringtone_qry_college = mysqli_query($connect, $wall_qry1);

    $wall_qry2 = "SELECT * FROM tbl_course";
    $ringtone_qry_course = mysqli_query($connect, $wall_qry2);

    $wall_qry3 = "SELECT * FROM tbl_tech";
    $ringtone_qry_tech = mysqli_query($connect, $wall_qry3);

?>



   <section class="content">
   
        <ol class="breadcrumb">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage-register.php">Manage Registration</a></li>
            <li class="active">Edit Registration</a></li>
        </ol>

       <div class="container-fluid">

            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                	<form id="form_validation" method="post" >
                    <div class="card">
                        <div class="header">
                            <h2>EDIT VIDEO</h2>
                                <?php if(isset($_SESSION['msg'])) { ?>
                                    <br><div class='alert alert-info'>Registration Successfully Updated...</div>
                                    <?php unset($_SESSION['msg']); } ?>
                        </div>
                        <div class="body">

                        	<div class="row clearfix">
                                
                                <div class="col-sm-5">

                                <div class="form-group">
                                        <div class="font-12">Name *</div>
                                        <div class="form-line">
                                            <input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?php echo $row['register_name'];?>" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Address *</div>
                                        <div class="form-line">
                                            <textarea name="address" id="address" class="form-control" placeholder="Address" required ><?php echo $row['register_address'];?></textarea>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Contact *</div>
                                        <div class="form-line">
                                            <input type="text" name="contact" id="contact" class="form-control" placeholder="Contact" value="<?php echo $row['register_contact'];?>" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Email *</div>
                                        <div class="form-line">
                                            <input type="email" name="email" id="email" class="form-control" placeholder="Email" value="<?php echo $row['register_email'];?>" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">DOB *</div>
                                        <div class="form-line">
                                            <input type="date" name="dob" id="dob" class="form-control" placeholder="Date of Birth" value="<?php echo $row['register_dob'];?>" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Parent Name *</div>
                                        <div class="form-line">
                                            <input type="text" name="pname" id="pname" class="form-control" placeholder="Parent Name" value="<?php echo $row['register_pname'];?>" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Parent Contact *</div>
                                        <div class="form-line">
                                            <input type="text" name="pcontact" id="pcontact" class="form-control" placeholder="Parent Contact" value="<?php echo $row['register_contact'];?>" required >
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">College</div>
                                        <select class="form-control show-tick" name="college_id" id="college_id">
                                           <?php 	
												while($r_c_row = mysqli_fetch_array($ringtone_qry_college)) {
													$sel = '';
													if ($r_c_row['college_id'] == $row['college_id']) {
													$sel = "selected";	
												}	
											?>
										    <option value="<?php echo $r_c_row['college_id'];?>" <?php echo $sel; ?>><?php echo $r_c_row['college_name'];?></option>
										                <?php }?>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="font-12">Course</div>
                                        <select class="form-control show-tick" name="course_id" id="course_id">
                                           <?php 	
												while($r_c_row = mysqli_fetch_array($ringtone_qry_course)) {
													$sel = '';
													if ($r_c_row['course_id'] == $row['course_id']) {
													$sel = "selected";	
												}	
											?>
										    <option value="<?php echo $r_c_row['course_id'];?>" <?php echo $sel; ?>><?php echo $r_c_row['course_name'];?></option>
										                <?php }?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Category</div>
                                        <select class="form-control show-tick" name="cat_id" id="cat_id">
                                           <?php 	
												while($r_c_row = mysqli_fetch_array($ringtone_qry_cat)) {
													$sel = '';
													if ($r_c_row['cid'] == $row['category_id']) {
													$sel = "selected";	
												}	
											?>
										    <option value="<?php echo $r_c_row['cid'];?>" <?php echo $sel; ?>><?php echo $r_c_row['category_name'];?></option>
										                <?php }?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <div class="font-12">Technology</div>
                                        <select class="form-control show-tick" name="tech_id" id="tech_id">
                                           <?php 	
												while($r_c_row = mysqli_fetch_array($ringtone_qry_tech)) {
													$sel = '';
													if ($r_c_row['tech_id'] == $row['tech_id']) {
													$sel = "selected";	
												}	
											?>
										    <option value="<?php echo $r_c_row['tech_id'];?>" <?php echo $sel; ?>><?php echo $r_c_row['tech_name'];?></option>
										                <?php }?>
                                        </select>
                                    </div>
                                   
									<input type="hidden" name="id" value="<?php echo $row['register_id'];?>">

                                    <button type="submit" name="submit" class="btn bg-blue waves-effect pull-right">UPDATE</button>
                                    
                                </div>

                            </div>
                        </div>
                    </div>
                    </form>

                </div>
            </div>
            
        </div>

    </section>