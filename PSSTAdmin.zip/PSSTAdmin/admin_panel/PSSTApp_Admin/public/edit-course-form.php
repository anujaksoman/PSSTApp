<?php include_once('functions.php'); ?>

<?php
    if (isset($_GET['id'])) {
        $ID = $_GET['id'];
    } else {
        $ID = "";
    }

    // create array variable to store category data
    $category_data = array();

    if (isset($_POST['btnEdit'])) {
        $course_name = $_POST['course_name'];

                $sql_query = "UPDATE tbl_course
                                SET course_name = ?
                                WHERE course_id = ?";

                $stmt = $connect->stmt_init();
                if ($stmt->prepare($sql_query)) {
                    // Bind your variables to replace the ?s
                    $stmt->bind_param('ss',
                        $course_name,
                        $ID);
                    // Execute query
                    $stmt->execute();
                    // store result
                    $update_result = $stmt->store_result();
                    $stmt->close();
                }
        

            // check update result
            if ($update_result) {
                $error['update_course'] = "<br><div class='alert alert-info'>Course Updated Successfully...</div>";
            } else {
                $error['update_course'] = "<br><div class='alert alert-danger'>Update Failed</div>";
            }

        }
    
    

    // create array variable to store previous data
    $data = array();

    $sql_query = "SELECT * FROM tbl_course WHERE course_id = ?";

    $stmt = $connect->stmt_init();
    if ($stmt->prepare($sql_query)) {
        // Bind your variables to replace the ?s
        $stmt->bind_param('s', $ID);
        // Execute query
        $stmt->execute();
        // store result
        $stmt->store_result();
        $stmt->bind_result($data['course_id'],
            $data['course_name']
        );
        $stmt->fetch();
        $stmt->close();
    }

?>

    <section class="content">

        <ol class="breadcrumb">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage-course.php">Manage Course</a></li>
            <li class="active">Edit Course</a></li>
        </ol>

       <div class="container-fluid">

            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                    <form id="form_validation" method="post" >
                    <div class="card">
                        <div class="header">
                            <h2>EDIT COURSE</h2>
                                <?php echo isset($error['update_course']) ? $error['update_course'] : ''; ?>
                        </div>
                        <div class="body">

                            <div class="row clearfix">
                                
                                <div>
                                    <div class="form-group col-sm-12">
                                        <div class="form-line">
                                            <div class="font-12">Course Name</div>
                                            <input type="text" class="form-control" name="course_name" id="course_name" value="<?php echo $data['course_name']; ?>" required>
                                            <!-- <label class="form-label">Category Name</label> -->
                                        </div>
                                    </div>


                                    <div class="col-sm-12">
                                         <button class="btn bg-blue waves-effect pull-right" type="submit" name="btnEdit">UPDATE</button>
                                    </div>

                                   
                                    
                                </div>

                            </div>
                        </div>
                    </div>
                    </form>

                </div>
            </div>
            
        </div>

    </section>