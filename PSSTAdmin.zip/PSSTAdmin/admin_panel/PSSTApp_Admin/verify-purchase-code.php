<?php include('session.php'); ?>
<?php include('public/verify-purchase-code-form.php'); ?>
<?php include('public/footer.php'); ?>