<?php

  $sql_category = "SELECT COUNT(*) as num FROM tbl_category";
  $total_category = mysqli_query($connect, $sql_category);
  $total_category = mysqli_fetch_array($total_category);
  $total_category = $total_category['num'];

  $sql_video = "SELECT COUNT(*) as num FROM tbl_gallery";
  $total_video = mysqli_query($connect, $sql_video);
  $total_video = mysqli_fetch_array($total_video);
  $total_video = $total_video['num'];

  $sql_fcm = "SELECT COUNT(*) as num FROM tbl_fcm_template";
  $total_fcm = mysqli_query($connect, $sql_fcm);
  $total_fcm = mysqli_fetch_array($total_fcm);
  $total_fcm = $total_fcm['num'];

  $sql_course = "SELECT COUNT(*) as num FROM tbl_course";
  $total_course = mysqli_query($connect, $sql_course);
  $total_course = mysqli_fetch_array($total_course);
  $total_course = $total_course['num'];

  $sql_college = "SELECT COUNT(*) as num FROM tbl_college";
  $total_college = mysqli_query($connect, $sql_college);
  $total_college = mysqli_fetch_array($total_college);
  $total_college = $total_college['num'];


  $sql_tech = "SELECT COUNT(*) as num FROM tbl_tech";
  $total_tech = mysqli_query($connect, $sql_tech);
  $total_tech = mysqli_fetch_array($total_tech);
  $total_tech = $total_tech['num'];


  $sql_register = "SELECT COUNT(*) as num FROM tbl_register";
  $total_register = mysqli_query($connect, $sql_register);
  $total_register= mysqli_fetch_array($total_register);
  $total_register = $total_register['num'];

?>

    <section class="content">

    <ol class="breadcrumb">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li class="active">Home</a></li>
    </ol>

        <div class="container-fluid">
             
             <div class="row">

                <a href="manage-category.php">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE CATEGORY</div>
                            <div class="color-name"><?php echo $total_category; ?></div>
                            <div class="color-class-name">Total Category</div>
                            <br>
                        </div>
                    </div>
                </a>

               <a href="manage-video.php">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE VIDEO</div>
                            <div class="color-name"><?php echo $total_video; ?></div>
                            <div class="color-class-name">Total Video</div>
                            <br>
                        </div>
                    </div>
                </a>

                <a href="push-notification.php">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">NOTIFICATION</div>
                            <div class="color-name"><?php echo $total_fcm; ?></div>
                            <div class="color-class-name">Total Template</div>
                            <br>
                        </div>
                    </div>
                </a>

                <a href="members.php">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">ADMINISTRATOR</div>
                            <div class="color-name"><i class="material-icons">people</i></div>
                            <div class="color-class-name">Admin Panel Privileges</div>
                            <br>
                        </div>
                    </div>
                </a>

                <a href="settings.php">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">SETTINGS</div>
                            <div class="color-name"><i class="material-icons">settings</i></div>
                            <div class="color-class-name">Key and Privacy Settings</div>
                            <br>
                        </div>
                    </div>
                </a>


                <a href="manage-register.php">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">STUDENT REGISTRATION</div>
                            <div class="color-name"><?php echo $total_register; ?></div>
                            <div class="color-class-name">Total Registration</div>
                            <br>
                        </div>
                    </div>
                </a>



                <a href="manage-course.php">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE COURSE</div>
                            <div class="color-name"><?php echo $total_course; ?></div>
                            <div class="color-class-name">Total Course</div>
                            <br>
                        </div>
                    </div>
                </a>


                
                <a href="manage-college.php">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE COLLEGE</div>
                            <div class="color-name"><?php echo $total_college; ?></div>
                            <div class="color-class-name">Total College</div>
                            <br>
                        </div>
                    </div>
                </a>


                <a href="manage-tech.php">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE TECHNOLOGY</div>
                            <div class="color-name"><?php echo $total_tech; ?></div>
                            <div class="color-class-name">Total Technology</div>
                            <br>
                        </div>
                    </div>
                </a>

            </div>
            
        </div>

    </section>