<?php include_once('functions.php'); ?>

<?php
    if (isset($_GET['id'])) {
        $ID = $_GET['id'];
    } else {
        $ID = "";
    }

    // create array variable to store category data
    $category_data = array();

    if (isset($_POST['btnEdit'])) {
        $college_name = $_POST['college_name'];

                $sql_query = "UPDATE tbl_college
                                SET college_name = ?
                                WHERE college_id = ?";

                $stmt = $connect->stmt_init();
                if ($stmt->prepare($sql_query)) {
                    // Bind your variables to replace the ?s
                    $stmt->bind_param('ss',
                        $college_name,
                        $ID);
                    // Execute query
                    $stmt->execute();
                    // store result
                    $update_result = $stmt->store_result();
                    $stmt->close();
                }
        

            // check update result
            if ($update_result) {
                $error['update_college'] = "<br><div class='alert alert-info'>College Updated Successfully...</div>";
            } else {
                $error['update_college'] = "<br><div class='alert alert-danger'>Update Failed</div>";
            }

        }
    
    

    // create array variable to store previous data
    $data = array();

    $sql_query = "SELECT * FROM tbl_college WHERE college_id = ?";

    $stmt = $connect->stmt_init();
    if ($stmt->prepare($sql_query)) {
        // Bind your variables to replace the ?s
        $stmt->bind_param('s', $ID);
        // Execute query
        $stmt->execute();
        // store result
        $stmt->store_result();
        $stmt->bind_result($data['college_id'],
            $data['college_name']
        );
        $stmt->fetch();
        $stmt->close();
    }

?>

    <section class="content">

        <ol class="breadcrumb">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage-college.php">Manage College</a></li>
            <li class="active">Edit College</a></li>
        </ol>

       <div class="container-fluid">

            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                    <form id="form_validation" method="post" >
                    <div class="card">
                        <div class="header">
                            <h2>EDIT COLLEGE</h2>
                                <?php echo isset($error['update_college']) ? $error['update_college'] : ''; ?>
                        </div>
                        <div class="body">

                            <div class="row clearfix">
                                
                                <div>
                                    <div class="form-group col-sm-12">
                                        <div class="form-line">
                                            <div class="font-12">College Name</div>
                                            <input type="text" class="form-control" name="college_name" id="college_name" value="<?php echo $data['college_name']; ?>" required>
                                            <!-- <label class="form-label">Category Name</label> -->
                                        </div>
                                    </div>


                                    <div class="col-sm-12">
                                         <button class="btn bg-blue waves-effect pull-right" type="submit" name="btnEdit">UPDATE</button>
                                    </div>

                                   
                                    
                                </div>

                            </div>
                        </div>
                    </div>
                    </form>

                </div>
            </div>
            
        </div>

    </section>