<?php include_once('functions.php'); ?>

<?php

if (isset($_POST['btnAdd'])) {

    $college_name = $_POST['college_name'];


    // create array variable to handle error
    $error = array();

    if(empty($college_name)){
        $error['college_name'] = " <span class='label label-danger'>Must Insert!</span>";
    }



    if(!empty($college_name)){
        // insert new data to menu table
        $sql_query = "INSERT INTO tbl_college(college_name)
                        VALUES(?)";

        $stmt = $connect->stmt_init();
        if($stmt->prepare($sql_query)) {
            // Bind your variables to replace the ?s
            $stmt->bind_param('s',
                $college_name
            );
            // Execute query
            $stmt->execute();
            // store result
            $result = $stmt->store_result();
            $stmt->close();
        }

        if($result) {
            $error['add_college'] = "<br><div class='alert alert-info'>New College Added Successfully...</div>";
        } else {
            $error['add_college'] = "<br><div class='alert alert-danger'>Added Failed</div>";
        }
    }

}

?> 

    <section class="content">

        <ol class="breadcrumb">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="manage-college.php">Manage College</a></li>
            <li class="active">Add College</a></li>
        </ol>

       <div class="container-fluid">

            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                	<form id="form_validation" method="post">
                    <div class="card">
                        <div class="header">
                            <h2>ADD COLLEGE</h2>
                                <?php echo isset($error['add_college']) ? $error['add_college'] : '';?>
                        </div>
                        <div class="body">

                        	<div class="row clearfix">
                                
                                <div>
                                    <div class="form-group form-float col-sm-12">
                                        <div class="form-line">
                                            <input type="text" class="form-control" name="college_name" id="college_name" required>
                                            <label class="form-label">College Name</label>
                                        </div>
                                    </div>


                                    <div class="col-sm-12">
                                         <button class="btn bg-blue waves-effect pull-right" type="submit" name="btnAdd">SUBMIT</button>
                                    </div>

                                   
                                    
                                </div>

                            </div>
                        </div>
                    </div>
                    </form>

                </div>
            </div>
            
        </div>

    </section>