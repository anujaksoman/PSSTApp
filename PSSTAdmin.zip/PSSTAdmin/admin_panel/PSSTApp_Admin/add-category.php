<?php include('session.php'); ?>
<?php include('public/menubar.php'); ?>
<?php include('public/add-category-form.php'); ?>
<?php include('public/footer.php'); ?>